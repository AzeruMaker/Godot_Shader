
# Godot Shader

GD Shader for Godot 4.3

## Roadmap

- Additional transition
- Add hint to each Shader
- Add commentary to each shader

## License

Please feel free to use the licence is 
[MIT](https://choosealicense.com/licenses/mit/)

## Hierarchy

```text
Shader
|-> Example (Simple example shader)
|-> Transition (Ready to use example for transition / Loading)

```

